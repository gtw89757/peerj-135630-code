* ==============================================================================.
* Reproducible analysis syntax for the PD-MRI KAP study.
* Software: IBM SPSS Statistics 26 or later.
* Input: peerj-135630-DATA.xlsx, Sheet1, 249 records, 61 raw variables.
* Run this file with the SPSS working directory set to the project root.
* The source workbook is read only and is never overwritten.
* ==============================================================================.

SET UNICODE=ON.
SET DECIMAL=DOT.

GET DATA
  /TYPE=XLSX
  /FILE='peerj-135630-DATA.xlsx'
  /SHEET=name 'Sheet1'
  /CELLRANGE=FULL
  /READNAMES=ON.
DATASET NAME KAP WINDOW=FRONT.

VARIABLE LABELS
 number 'Participant record number'
 sex 'Gender'
 age 'Age group'
 education_level 'Highest education level'
 institution_type 'Institution type'
 department 'Department/subspecialty'
 years_in_department 'Years working in the department'
 professional_title 'Professional title'
 job_satisfaction 'Current job satisfaction'.

VALUE LABELS
 sex 1 'Male' 2 'Female'
 /age 1 'Less than 35 years' 2 '35-60 years' 3 'More than 60 years'
 /education_level 1 'Junior college or below' 2 'Undergraduate' 3 'Postgraduate or above'
 /institution_type 1 'Public tertiary hospital' 2 'Public secondary hospital'
                   3 'Public community hospital/health center' 4 'Private hospital'
 /department 1 'Comprehensive neurology'
             2 'Parkinson disease and movement disorders subspecialty'
             3 'Cerebrovascular disease subspecialty'
             4 'Cognitive disorders subspecialty' 5 'Other'
 /years_in_department 1 'Less than 1 year' 2 '1-2 years' 3 '3-5 years'
                      4 '6-10 years' 5 'More than 10 years'
 /professional_title 1 'Resident physician' 2 'Attending physician'
                     3 'Associate chief physician' 4 'Chief physician'
 /job_satisfaction 1 'Very satisfied' 2 'Relatively satisfied' 3 'Neutral'
                   4 'Not very satisfied' 5 'Very dissatisfied'.

VALUE LABELS K1 TO K11 1 'True' 2 'False' 3 'Unsure'.
VALUE LABELS A1 TO A12 1 'Strongly agree' 2 'Agree' 3 'Neutral'
                        4 'Disagree' 5 'Strongly disagree'.
VALUE LABELS P1 TO P7 1 'Always' 2 'Often' 3 'Sometimes'
                       4 'Occasionally' 5 'Never'.
VALUE LABELS P8a TO P11f 0 'Not selected' 1 'Selected'.

* ----- Data integrity checks -----.
FREQUENCIES VARIABLES=sex age education_level institution_type department
 years_in_department professional_title job_satisfaction K1 TO K11 A1 TO A12
 P1 TO P7 P8a TO P11f
 /ORDER=ANALYSIS.

* ----- Item scoring -----.
* Knowledge correct-answer key: a b b b a a b a a b b; a=1, b=2, c=3.
COMPUTE K1_s=(K1=1).
COMPUTE K2_s=(K2=2).
COMPUTE K3_s=(K3=2).
COMPUTE K4_s=(K4=2).
COMPUTE K5_s=(K5=1).
COMPUTE K6_s=(K6=1).
COMPUTE K7_s=(K7=2).
COMPUTE K8_s=(K8=1).
COMPUTE K9_s=(K9=1).
COMPUTE K10_s=(K10=2).
COMPUTE K11_s=(K11=2).
COMPUTE Ksum=SUM(K1_s TO K11_s).

* Positive attitude items: A1, A3, A6-A12; negative/reverse items: A2, A4, A5.
COMPUTE A1_s=6-A1.
COMPUTE A2_s=A2.
COMPUTE A3_s=6-A3.
COMPUTE A4_s=A4.
COMPUTE A5_s=A5.
COMPUTE A6_s=6-A6.
COMPUTE A7_s=6-A7.
COMPUTE A8_s=6-A8.
COMPUTE A9_s=6-A9.
COMPUTE A10_s=6-A10.
COMPUTE A11_s=6-A11.
COMPUTE A12_s=6-A12.
COMPUTE Asum=SUM(A1_s TO A12_s).

* Only P1-P7 are scored. P8-P11 are multiple-response items and are not scored.
COMPUTE P1_s=6-P1.
COMPUTE P2_s=6-P2.
COMPUTE P3_s=6-P3.
COMPUTE P4_s=6-P4.
COMPUTE P5_s=6-P5.
COMPUTE P6_s=6-P6.
COMPUTE P7_s=6-P7.
COMPUTE Psum=SUM(P1_s TO P7_s).

VARIABLE LABELS Ksum 'Knowledge score (0-11)'
 Asum 'Attitude score (12-60)' Psum 'Practice score (7-35)'.
FORMATS Ksum Asum Psum (F8.0).
EXECUTE.

* ----- Binary outcomes and grouped covariates used in the archived regressions -----.
COMPUTE K_good=(Ksum>=9).
COMPUTE A_good=(Asum>=42).
COMPUTE P_good=(Psum>=24).
VALUE LABELS K_good A_good P_good 0 'Below cutoff' 1 'At/above cutoff'.

RECODE age (1=1) (2,3=2) INTO age2.
RECODE education_level (1,2=1) (3=2) INTO education2.
RECODE institution_type (1=1) (2=2) (3,4=3) INTO institution3.
RECODE department (1=1) (2=2) (3=3) (4,5=4) INTO department4.
RECODE years_in_department (1,2,3=1) (4=2) (5=3) INTO years3.
RECODE professional_title (1=1) (2=2) (3,4=3) INTO title3.
RECODE job_satisfaction (1=1) (2=2) (3,4,5=3) INTO satisfaction3.

VALUE LABELS
 age2 1 'Less than 35 years' 2 '35 years or above'
 /education2 1 'Junior college/undergraduate or below' 2 'Postgraduate or above'
 /institution3 1 'Public tertiary hospital' 2 'Public secondary hospital' 3 'Other institution'
 /department4 1 'Comprehensive neurology' 2 'PD/movement disorders'
              3 'Cerebrovascular disease' 4 'Other department'
 /years3 1 '1-5 years' 2 '6-10 years' 3 'More than 10 years'
 /title3 1 'Resident physician' 2 'Attending physician'
         3 'Associate chief/chief physician'
 /satisfaction3 1 'Very satisfied' 2 'Relatively satisfied'
                3 'Neutral/not satisfied'.
EXECUTE.

* ----- Descriptive statistics, score distributions, and reliability -----.
DESCRIPTIVES VARIABLES=Ksum Asum Psum /STATISTICS=MEAN STDDEV MIN MAX.
FREQUENCIES VARIABLES=K1_s TO K11_s A1 TO A12 P1 TO P7 P8a TO P11f
 /ORDER=ANALYSIS.

RELIABILITY
 /VARIABLES=K1_s TO K11_s
 /SCALE('Knowledge') ALL
 /MODEL=ALPHA.
RELIABILITY
 /VARIABLES=A1_s TO A12_s
 /SCALE('Attitude') ALL
 /MODEL=ALPHA.
RELIABILITY
 /VARIABLES=P1_s TO P7_s
 /SCALE('Practice') ALL
 /MODEL=ALPHA.

* ----- Baseline comparisons reported as mean +/- SD with t test or one-way ANOVA -----.
T-TEST GROUPS=sex(1 2) /VARIABLES=Ksum Asum Psum /CRITERIA=CI(.95).
T-TEST GROUPS=education2(1 2) /VARIABLES=Ksum Asum Psum /CRITERIA=CI(.95).
ONEWAY Ksum Asum Psum BY age /STATISTICS DESCRIPTIVES HOMOGENEITY /POSTHOC=BONFERRONI ALPHA(.05).
ONEWAY Ksum Asum Psum BY institution_type /STATISTICS DESCRIPTIVES HOMOGENEITY /POSTHOC=BONFERRONI ALPHA(.05).
ONEWAY Ksum Asum Psum BY department /STATISTICS DESCRIPTIVES HOMOGENEITY /POSTHOC=BONFERRONI ALPHA(.05).
ONEWAY Ksum Asum Psum BY years3 /STATISTICS DESCRIPTIVES HOMOGENEITY /POSTHOC=BONFERRONI ALPHA(.05).
ONEWAY Ksum Asum Psum BY professional_title /STATISTICS DESCRIPTIVES HOMOGENEITY /POSTHOC=BONFERRONI ALPHA(.05).
ONEWAY Ksum Asum Psum BY job_satisfaction /STATISTICS DESCRIPTIVES HOMOGENEITY /POSTHOC=BONFERRONI ALPHA(.05).

* ----- Pearson correlations (Table 5) -----.
CORRELATIONS
 /VARIABLES=Ksum Asum Psum
 /PRINT=TWOTAIL SIG
 /MISSING=PAIRWISE.

* ----- Univariate logistic regressions: Knowledge outcome -----.
LOGISTIC REGRESSION VARIABLES K_good WITH sex
 /CATEGORICAL=sex /CONTRAST(sex)=Indicator(1) /METHOD=ENTER sex /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES K_good WITH age2
 /CATEGORICAL=age2 /CONTRAST(age2)=Indicator(1) /METHOD=ENTER age2 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES K_good WITH education2
 /CATEGORICAL=education2 /CONTRAST(education2)=Indicator(1) /METHOD=ENTER education2 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES K_good WITH institution3
 /CATEGORICAL=institution3 /CONTRAST(institution3)=Indicator(1) /METHOD=ENTER institution3 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES K_good WITH department4
 /CATEGORICAL=department4 /CONTRAST(department4)=Indicator(1) /METHOD=ENTER department4 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES K_good WITH years3
 /CATEGORICAL=years3 /CONTRAST(years3)=Indicator(1) /METHOD=ENTER years3 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES K_good WITH title3
 /CATEGORICAL=title3 /CONTRAST(title3)=Indicator(1) /METHOD=ENTER title3 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES K_good WITH satisfaction3
 /CATEGORICAL=satisfaction3 /CONTRAST(satisfaction3)=Indicator(1) /METHOD=ENTER satisfaction3 /PRINT=CI(95).

* ----- Univariate logistic regressions: Attitude outcome -----.
LOGISTIC REGRESSION VARIABLES A_good WITH Ksum /METHOD=ENTER Ksum /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES A_good WITH sex
 /CATEGORICAL=sex /CONTRAST(sex)=Indicator(1) /METHOD=ENTER sex /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES A_good WITH age2
 /CATEGORICAL=age2 /CONTRAST(age2)=Indicator(1) /METHOD=ENTER age2 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES A_good WITH education2
 /CATEGORICAL=education2 /CONTRAST(education2)=Indicator(1) /METHOD=ENTER education2 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES A_good WITH institution3
 /CATEGORICAL=institution3 /CONTRAST(institution3)=Indicator(1) /METHOD=ENTER institution3 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES A_good WITH department4
 /CATEGORICAL=department4 /CONTRAST(department4)=Indicator(1) /METHOD=ENTER department4 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES A_good WITH years3
 /CATEGORICAL=years3 /CONTRAST(years3)=Indicator(1) /METHOD=ENTER years3 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES A_good WITH title3
 /CATEGORICAL=title3 /CONTRAST(title3)=Indicator(1) /METHOD=ENTER title3 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES A_good WITH satisfaction3
 /CATEGORICAL=satisfaction3 /CONTRAST(satisfaction3)=Indicator(1) /METHOD=ENTER satisfaction3 /PRINT=CI(95).

* ----- Univariate logistic regressions: Practice outcome -----.
LOGISTIC REGRESSION VARIABLES P_good WITH Ksum /METHOD=ENTER Ksum /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES P_good WITH Asum /METHOD=ENTER Asum /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES P_good WITH sex
 /CATEGORICAL=sex /CONTRAST(sex)=Indicator(1) /METHOD=ENTER sex /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES P_good WITH age2
 /CATEGORICAL=age2 /CONTRAST(age2)=Indicator(1) /METHOD=ENTER age2 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES P_good WITH education2
 /CATEGORICAL=education2 /CONTRAST(education2)=Indicator(1) /METHOD=ENTER education2 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES P_good WITH institution3
 /CATEGORICAL=institution3 /CONTRAST(institution3)=Indicator(1) /METHOD=ENTER institution3 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES P_good WITH department4
 /CATEGORICAL=department4 /CONTRAST(department4)=Indicator(1) /METHOD=ENTER department4 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES P_good WITH years3
 /CATEGORICAL=years3 /CONTRAST(years3)=Indicator(1) /METHOD=ENTER years3 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES P_good WITH title3
 /CATEGORICAL=title3 /CONTRAST(title3)=Indicator(1) /METHOD=ENTER title3 /PRINT=CI(95).
LOGISTIC REGRESSION VARIABLES P_good WITH satisfaction3
 /CATEGORICAL=satisfaction3 /CONTRAST(satisfaction3)=Indicator(1) /METHOD=ENTER satisfaction3 /PRINT=CI(95).

* ----- Multivariable models used for the archived ORs -----.
* Institution type is retained because it was included in the archived adjusted models.
LOGISTIC REGRESSION VARIABLES K_good WITH institution3 years3
 /CATEGORICAL=institution3 years3
 /CONTRAST(institution3)=Indicator(1) /CONTRAST(years3)=Indicator(1)
 /METHOD=ENTER institution3 years3 /PRINT=CI(95) GOODFIT.

LOGISTIC REGRESSION VARIABLES A_good WITH education2 institution3 title3
 /CATEGORICAL=education2 institution3 title3
 /CONTRAST(education2)=Indicator(1) /CONTRAST(institution3)=Indicator(1)
 /CONTRAST(title3)=Indicator(1)
 /METHOD=ENTER education2 institution3 title3 /PRINT=CI(95) GOODFIT.

LOGISTIC REGRESSION VARIABLES P_good WITH Asum institution3 title3
 /CATEGORICAL=institution3 title3
 /CONTRAST(institution3)=Indicator(1) /CONTRAST(title3)=Indicator(1)
 /METHOD=ENTER Asum institution3 title3 /PRINT=CI(95) GOODFIT.

* ----- VIF/tolerance checks for final multivariable predictor sets -----.
COMPUTE inst_public_secondary=(institution3=2).
COMPUTE inst_other=(institution3=3).
COMPUTE years_6_10=(years3=2).
COMPUTE years_gt10=(years3=3).
COMPUTE edu_postgrad=(education2=2).
COMPUTE title_attending=(title3=2).
COMPUTE title_senior=(title3=3).
EXECUTE.

REGRESSION /DEPENDENT K_good
 /METHOD=ENTER inst_public_secondary inst_other years_6_10 years_gt10
 /STATISTICS=COEFF OUTS R ANOVA COLLIN TOL.
REGRESSION /DEPENDENT A_good
 /METHOD=ENTER edu_postgrad inst_public_secondary inst_other title_attending title_senior
 /STATISTICS=COEFF OUTS R ANOVA COLLIN TOL.
REGRESSION /DEPENDENT P_good
 /METHOD=ENTER Asum inst_public_secondary inst_other title_attending title_senior
 /STATISTICS=COEFF OUTS R ANOVA COLLIN TOL.

* ----- Optional scored-data export; uncomment if required -----.
* SAVE TRANSLATE OUTFILE='deliverables/peerj-135630-DATA_scored.xlsx'
*  /TYPE=XLSX /VERSION=12 /MAP /REPLACE /FIELDNAMES /CELLS=VALUES.

* Structural equation modeling is not executed by base SPSS Statistics syntax.
* Use PD_MRI_KAP_SEM.R for a scripted lavaan reproduction, or open the archived
* AMOS model PD_MRI_KAP_SEM.amw in IBM SPSS Amos.

