# Reproducible structural equation/path model for the PD-MRI KAP study
# Input: ../peerj-135630-DATA.xlsx
# R packages: readxl, lavaan

required <- c("readxl", "lavaan")
missing_packages <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages)) {
  stop(
    "Install the required packages before running: ",
    paste(missing_packages, collapse = ", ")
  )
}

data_path <- file.path("..", "peerj-135630-DATA.xlsx")
if (!file.exists(data_path)) {
  data_path <- "peerj-135630-DATA.xlsx"
}
dat <- readxl::read_excel(data_path, sheet = "Sheet1")

knowledge_key <- c(K1 = 1, K2 = 2, K3 = 2, K4 = 2, K5 = 1, K6 = 1,
                   K7 = 2, K8 = 1, K9 = 1, K10 = 2, K11 = 2)
positive_attitude <- c("A1", "A3", paste0("A", 6:12))
negative_attitude <- c("A2", "A4", "A5")

dat$Ksum <- rowSums(vapply(names(knowledge_key), function(v) {
  as.integer(dat[[v]] == knowledge_key[[v]])
}, integer(nrow(dat))))

dat$Asum <- rowSums(cbind(
  vapply(positive_attitude, function(v) 6 - dat[[v]], numeric(nrow(dat))),
  vapply(negative_attitude, function(v) dat[[v]], numeric(nrow(dat)))
))

dat$Psum <- rowSums(vapply(paste0("P", 1:7), function(v) {
  6 - dat[[v]]
}, numeric(nrow(dat))))

# This is the path structure represented by the archived AMOS files.
# professional_title is treated as the original ordered 1-4 covariate, matching
# the archived coefficients. The model estimates direct effects of knowledge and
# job title on attitude and practice, plus attitude on practice.
model <- '
  Asum ~ Ksum + professional_title
  Psum ~ Ksum + Asum + professional_title
'

fit <- lavaan::sem(
  model,
  data = dat,
  estimator = "ML",
  meanstructure = TRUE,
  fixed.x = TRUE
)

print(summary(fit, standardized = TRUE, fit.measures = TRUE, rsquare = TRUE))

fit_indices <- lavaan::fitMeasures(
  fit,
  c("chisq", "df", "pvalue", "rmsea", "ifi", "tli", "gfi", "agfi")
)
print(fit_indices)

paths <- lavaan::parameterEstimates(fit, standardized = TRUE)
paths <- paths[paths$op == "~", c("lhs", "op", "rhs", "est", "se", "z", "pvalue", "std.all")]
print(paths, row.names = FALSE)

write.csv(paths, "PD_MRI_KAP_SEM_path_estimates.csv", row.names = FALSE)
write.csv(as.data.frame(t(fit_indices)), "PD_MRI_KAP_SEM_fit_indices.csv", row.names = FALSE)

cat("\nSession information\n")
print(sessionInfo())

